<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    public function index()
    {
        $taskModel = new TaskModel();

        return view('tasks', [
            'tasks' => $taskModel->getAllTasks()
        ]);
    }
}
